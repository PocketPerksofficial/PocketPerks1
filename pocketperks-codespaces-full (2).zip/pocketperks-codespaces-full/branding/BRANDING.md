# PocketPerks — Branding
Tagline: Tap. Save. Repeat.

Use `pocketperks-icon.png` as your app/logo in AppSheet or future native builds.

Colors:
- Electric Coral: #FF6B6B
- Warm Peach: #FFD3B6
- Mint Green: #2ECC71
- Charcoal: #2D3436
